﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BTTH2_6
{
    public partial class Form1 : Form
    {
        private int n;
        private int[] arr;
        Random rand = new Random();
        public Form1()
        {
            InitializeComponent();
        }

        private void createBt_Click(object sender, EventArgs e)
        {
            try
            {
                n = int.Parse(numTxt.Text);
                arr = new int[n];
                for (int i = 0; i < n; i++)
                {
                    arr[i] = rand.Next(0, 100);
                }
                arrTxt.Text = String.Join(",", arr);
            }
            catch (FormatException)
            {
                MessageBox.Show("Vui lòng nhập số để tạo mảng");
            }
            catch (OverflowException)
            {
                MessageBox.Show("Số quá lớn hoặc quá nhỏ");
            }

        }

        private void Sort()
        {
            int[] method = new int[n];
            // tang
            arr.CopyTo(method, 0);
            Array.Sort(method);
            increaseTxt.Text = String.Join(",", method);

            // giam
            Array.Reverse(method);
            decreaseTxt.Text = String.Join(",", method);

            // dao nguoc
            arr.CopyTo(method, 0);
            Array.Reverse(method);
            reverseTxt.Text = String.Join(",", method);
        }

        private void SortSpecial()
        {
            var even = arr.Where(x => x % 2 == 0).OrderBy(x => x);
            var odd = arr.Where(x => x % 2 != 0).OrderByDescending(x => x);
            oddEvenTxt.Text = String.Join(",", even.Concat(odd));
        }

        private void SortBt_Click(object sender, EventArgs e)
        {
            try
            {
                // tang , giam, dao
                Sort();
                // mang chan tang le giam
                SortSpecial();
            }
            catch (FormatException)
            {
                MessageBox.Show("Vui lòng nhập số để tạo mảng");
            }
            catch (OverflowException)
            {
                MessageBox.Show("Số quá lớn hoặc quá nhỏ");
            }
        }
    }
}
