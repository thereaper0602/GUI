﻿namespace BTTH2_6
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.numTxt = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.arrTxt = new System.Windows.Forms.TextBox();
            this.label = new System.Windows.Forms.Label();
            this.increaseTxt = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.decreaseTxt = new System.Windows.Forms.TextBox();
            this.label_ = new System.Windows.Forms.Label();
            this.reverseTxt = new System.Windows.Forms.TextBox();
            this.oddEven = new System.Windows.Forms.Label();
            this.oddEvenTxt = new System.Windows.Forms.TextBox();
            this.createBt = new System.Windows.Forms.Button();
            this.SortBt = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(38, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(66, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "Số phần tử";
            // 
            // numTxt
            // 
            this.numTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numTxt.Location = new System.Drawing.Point(110, 27);
            this.numTxt.Name = "numTxt";
            this.numTxt.Size = new System.Drawing.Size(87, 21);
            this.numTxt.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(38, 85);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 15);
            this.label2.TabIndex = 0;
            this.label2.Text = "Mảng ban đầu";
            // 
            // arrTxt
            // 
            this.arrTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.arrTxt.Location = new System.Drawing.Point(237, 85);
            this.arrTxt.Name = "arrTxt";
            this.arrTxt.Size = new System.Drawing.Size(413, 21);
            this.arrTxt.TabIndex = 1;
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label.Location = new System.Drawing.Point(38, 140);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(66, 15);
            this.label.TabIndex = 0;
            this.label.Text = "Mảng tăng";
            // 
            // increaseTxt
            // 
            this.increaseTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.increaseTxt.Location = new System.Drawing.Point(237, 137);
            this.increaseTxt.Name = "increaseTxt";
            this.increaseTxt.Size = new System.Drawing.Size(413, 21);
            this.increaseTxt.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(38, 195);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(70, 15);
            this.label4.TabIndex = 0;
            this.label4.Text = "Mảng giảm";
            // 
            // decreaseTxt
            // 
            this.decreaseTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.decreaseTxt.Location = new System.Drawing.Point(237, 192);
            this.decreaseTxt.Name = "decreaseTxt";
            this.decreaseTxt.Size = new System.Drawing.Size(413, 21);
            this.decreaseTxt.TabIndex = 1;
            // 
            // label_
            // 
            this.label_.AutoSize = true;
            this.label_.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_.Location = new System.Drawing.Point(38, 250);
            this.label_.Name = "label_";
            this.label_.Size = new System.Drawing.Size(63, 15);
            this.label_.TabIndex = 0;
            this.label_.Text = "Mảng đảo";
            // 
            // reverseTxt
            // 
            this.reverseTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reverseTxt.Location = new System.Drawing.Point(237, 247);
            this.reverseTxt.Name = "reverseTxt";
            this.reverseTxt.Size = new System.Drawing.Size(413, 21);
            this.reverseTxt.TabIndex = 1;
            // 
            // oddEven
            // 
            this.oddEven.AutoSize = true;
            this.oddEven.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.oddEven.Location = new System.Drawing.Point(38, 305);
            this.oddEven.Name = "oddEven";
            this.oddEven.Size = new System.Drawing.Size(140, 15);
            this.oddEven.TabIndex = 0;
            this.oddEven.Text = "Mảng chẵn tăng,lẻ giảm";
            // 
            // oddEvenTxt
            // 
            this.oddEvenTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.oddEvenTxt.Location = new System.Drawing.Point(237, 302);
            this.oddEvenTxt.Name = "oddEvenTxt";
            this.oddEvenTxt.Size = new System.Drawing.Size(413, 21);
            this.oddEvenTxt.TabIndex = 1;
            // 
            // createBt
            // 
            this.createBt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.createBt.Location = new System.Drawing.Point(237, 30);
            this.createBt.Name = "createBt";
            this.createBt.Size = new System.Drawing.Size(183, 30);
            this.createBt.TabIndex = 2;
            this.createBt.Text = "Tạo mảng";
            this.createBt.UseVisualStyleBackColor = true;
            this.createBt.Click += new System.EventHandler(this.createBt_Click);
            // 
            // SortBt
            // 
            this.SortBt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SortBt.Location = new System.Drawing.Point(467, 30);
            this.SortBt.Name = "SortBt";
            this.SortBt.Size = new System.Drawing.Size(183, 30);
            this.SortBt.TabIndex = 2;
            this.SortBt.Text = "Sắp xếp";
            this.SortBt.UseVisualStyleBackColor = true;
            this.SortBt.Click += new System.EventHandler(this.SortBt_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(685, 376);
            this.Controls.Add(this.SortBt);
            this.Controls.Add(this.createBt);
            this.Controls.Add(this.oddEvenTxt);
            this.Controls.Add(this.reverseTxt);
            this.Controls.Add(this.decreaseTxt);
            this.Controls.Add(this.increaseTxt);
            this.Controls.Add(this.arrTxt);
            this.Controls.Add(this.numTxt);
            this.Controls.Add(this.oddEven);
            this.Controls.Add(this.label_);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox numTxt;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox arrTxt;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.TextBox increaseTxt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox decreaseTxt;
        private System.Windows.Forms.Label label_;
        private System.Windows.Forms.TextBox reverseTxt;
        private System.Windows.Forms.Label oddEven;
        private System.Windows.Forms.TextBox oddEvenTxt;
        private System.Windows.Forms.Button createBt;
        private System.Windows.Forms.Button SortBt;
    }
}

