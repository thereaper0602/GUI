﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.s1Txt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.s2Txt = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.insertTxt = new System.Windows.Forms.TextBox();
            this.label = new System.Windows.Forms.Label();
            this.toTxt = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.fromTxt = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.s3Txt = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.insertBt = new System.Windows.Forms.Button();
            this.getSubString = new System.Windows.Forms.Button();
            this.restoreBt = new System.Windows.Forms.Button();
            this.replaceS2 = new System.Windows.Forms.Button();
            this.reverseS1Bt = new System.Windows.Forms.Button();
            this.delS2 = new System.Windows.Forms.Button();
            this.normalizedBt = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(1, -1);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(860, 61);
            this.label1.TabIndex = 0;
            this.label1.Text = "label1";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(45, 104);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Chuỗi s1";
            // 
            // s1Txt
            // 
            this.s1Txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.s1Txt.Location = new System.Drawing.Point(112, 103);
            this.s1Txt.Name = "s1Txt";
            this.s1Txt.Size = new System.Drawing.Size(619, 22);
            this.s1Txt.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(45, 169);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 16);
            this.label3.TabIndex = 1;
            this.label3.Text = "Chuỗi s2";
            // 
            // s2Txt
            // 
            this.s2Txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.s2Txt.Location = new System.Drawing.Point(112, 168);
            this.s2Txt.Name = "s2Txt";
            this.s2Txt.Size = new System.Drawing.Size(202, 22);
            this.s2Txt.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(10, 52);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(31, 16);
            this.label4.TabIndex = 1;
            this.label4.Text = "vị trí";
            // 
            // insertTxt
            // 
            this.insertTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.insertTxt.Location = new System.Drawing.Point(77, 51);
            this.insertTxt.Name = "insertTxt";
            this.insertTxt.Size = new System.Drawing.Size(153, 22);
            this.insertTxt.TabIndex = 2;
            // 
            // label
            // 
            this.label.AutoSize = true;
            this.label.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label.Location = new System.Drawing.Point(201, 35);
            this.label.Name = "label";
            this.label.Size = new System.Drawing.Size(55, 16);
            this.label.TabIndex = 1;
            this.label.Text = "Số ký tự";
            // 
            // toTxt
            // 
            this.toTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toTxt.Location = new System.Drawing.Point(268, 35);
            this.toTxt.Name = "toTxt";
            this.toTxt.Size = new System.Drawing.Size(61, 22);
            this.toTxt.TabIndex = 2;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(24, 35);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(50, 16);
            this.label7.TabIndex = 1;
            this.label7.Text = "Từ vị trí";
            // 
            // fromTxt
            // 
            this.fromTxt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fromTxt.Location = new System.Drawing.Point(91, 34);
            this.fromTxt.Name = "fromTxt";
            this.fromTxt.Size = new System.Drawing.Size(69, 22);
            this.fromTxt.TabIndex = 2;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(443, 167);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(59, 16);
            this.label8.TabIndex = 1;
            this.label8.Text = "Chuỗi s3";
            // 
            // s3Txt
            // 
            this.s3Txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.s3Txt.Location = new System.Drawing.Point(510, 166);
            this.s3Txt.Name = "s3Txt";
            this.s3Txt.Size = new System.Drawing.Size(221, 22);
            this.s3Txt.TabIndex = 2;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.insertBt);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.insertTxt);
            this.groupBox1.Location = new System.Drawing.Point(48, 229);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(325, 105);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Chèn s2 vào s1";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.getSubString);
            this.groupBox2.Controls.Add(this.label);
            this.groupBox2.Controls.Add(this.toTxt);
            this.groupBox2.Controls.Add(this.fromTxt);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Location = new System.Drawing.Point(48, 357);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(432, 84);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Lấy chuỗi con trong s1";
            // 
            // insertBt
            // 
            this.insertBt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.insertBt.Location = new System.Drawing.Point(243, 52);
            this.insertBt.Name = "insertBt";
            this.insertBt.Size = new System.Drawing.Size(76, 21);
            this.insertBt.TabIndex = 3;
            this.insertBt.Text = "Chèn";
            this.insertBt.UseVisualStyleBackColor = true;
            this.insertBt.Click += new System.EventHandler(this.insertBt_Click);
            // 
            // getSubString
            // 
            this.getSubString.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.getSubString.Location = new System.Drawing.Point(348, 34);
            this.getSubString.Name = "getSubString";
            this.getSubString.Size = new System.Drawing.Size(74, 22);
            this.getSubString.TabIndex = 3;
            this.getSubString.Text = "Lấy chuỗi con";
            this.getSubString.UseVisualStyleBackColor = true;
            this.getSubString.Click += new System.EventHandler(this.getSubString_Click);
            // 
            // restoreBt
            // 
            this.restoreBt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.restoreBt.Location = new System.Drawing.Point(622, 388);
            this.restoreBt.Name = "restoreBt";
            this.restoreBt.Size = new System.Drawing.Size(92, 34);
            this.restoreBt.TabIndex = 3;
            this.restoreBt.Text = "Khôi phục";
            this.restoreBt.UseVisualStyleBackColor = true;
            this.restoreBt.Click += new System.EventHandler(this.restoreBt_Click);
            // 
            // replaceS2
            // 
            this.replaceS2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.replaceS2.Location = new System.Drawing.Point(510, 250);
            this.replaceS2.Name = "replaceS2";
            this.replaceS2.Size = new System.Drawing.Size(138, 35);
            this.replaceS2.TabIndex = 3;
            this.replaceS2.Text = "Chuyển s2 bằng s3";
            this.replaceS2.UseVisualStyleBackColor = true;
            this.replaceS2.Click += new System.EventHandler(this.replaceS2_Click);
            // 
            // reverseS1Bt
            // 
            this.reverseS1Bt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.reverseS1Bt.Location = new System.Drawing.Point(663, 250);
            this.reverseS1Bt.Name = "reverseS1Bt";
            this.reverseS1Bt.Size = new System.Drawing.Size(134, 35);
            this.reverseS1Bt.TabIndex = 3;
            this.reverseS1Bt.Text = "Đảo từ trong s1";
            this.reverseS1Bt.UseVisualStyleBackColor = true;
            this.reverseS1Bt.Click += new System.EventHandler(this.reverseS1Bt_Click);
            // 
            // delS2
            // 
            this.delS2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.delS2.Location = new System.Drawing.Point(510, 303);
            this.delS2.Name = "delS2";
            this.delS2.Size = new System.Drawing.Size(138, 35);
            this.delS2.TabIndex = 3;
            this.delS2.Text = "Xóa s2 trong s1";
            this.delS2.UseVisualStyleBackColor = true;
            this.delS2.Click += new System.EventHandler(this.delS2_Click);
            // 
            // normalizedBt
            // 
            this.normalizedBt.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.normalizedBt.Location = new System.Drawing.Point(663, 303);
            this.normalizedBt.Name = "normalizedBt";
            this.normalizedBt.Size = new System.Drawing.Size(134, 35);
            this.normalizedBt.TabIndex = 3;
            this.normalizedBt.Text = "Chuẩn hóa chuỗi";
            this.normalizedBt.UseVisualStyleBackColor = true;
            this.normalizedBt.Click += new System.EventHandler(this.normalizedBt_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(860, 470);
            this.Controls.Add(this.reverseS1Bt);
            this.Controls.Add(this.normalizedBt);
            this.Controls.Add(this.delS2);
            this.Controls.Add(this.replaceS2);
            this.Controls.Add(this.restoreBt);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.s3Txt);
            this.Controls.Add(this.s2Txt);
            this.Controls.Add(this.s1Txt);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox s1Txt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox s2Txt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox insertTxt;
        private System.Windows.Forms.Label label;
        private System.Windows.Forms.TextBox toTxt;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox fromTxt;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox s3Txt;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button insertBt;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button getSubString;
        private System.Windows.Forms.Button restoreBt;
        private System.Windows.Forms.Button replaceS2;
        private System.Windows.Forms.Button reverseS1Bt;
        private System.Windows.Forms.Button delS2;
        private System.Windows.Forms.Button normalizedBt;
        private System.Windows.Forms.Timer timer1;
    }
}

