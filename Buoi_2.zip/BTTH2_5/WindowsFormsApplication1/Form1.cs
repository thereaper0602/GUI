﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        string restore;
        public Form1()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Text = label1.Text.Substring(1, label1.Text.Length - 1) + label1.Text.Substring(0,1);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label1.Text = "   CHƯƠNG TRÌNH MINH HỌA XỬ LÝ CHUỖI   ";
        }

        private void insertBt_Click(object sender, EventArgs e)
        {
            getOrigin();
            int pos = int.Parse(insertTxt.Text);
            if (pos < 0 || pos > s1Txt.Text.Length) return;
            s1Txt.Text = s1Txt.Text.Insert(pos, s2Txt.Text);
        }

        private void replaceS2_Click(object sender, EventArgs e)
        {
            getOrigin();
            try
            {
                s1Txt.Text = s1Txt.Text.Replace(s2Txt.Text, s3Txt.Text);
            }
            catch
            {

            }
        }

        private void reverseS1Bt_Click(object sender, EventArgs e)
        {
            getOrigin();
            string[] words = s1Txt.Text.Split(' ');
            Array.Reverse(words);
            s1Txt.Text =  String.Join(" ", words);
        }

        private void delS2_Click(object sender, EventArgs e)
        {
            getOrigin();
            string[] arr = s1Txt.Text.Split(' ');
            for(int i = 0; i < arr.Length; i++)
            {
                if (arr[i].Contains(s2Txt.Text))
                {
                    int start = arr[i].IndexOf(s2Txt.Text);
                    int end = s2Txt.Text.Length;
                    arr[i] = arr[i].Remove(start, end);
                }
            }
            s1Txt.Text = String.Join(" ", arr);
        }

        private void normalizedBt_Click(object sender, EventArgs e)
        {
            getOrigin();
            s1Txt.Text.Trim();
            char[] tokens = { ' ', '\r', '\n' };
            string[] arr = s1Txt.Text.Split(tokens,StringSplitOptions.RemoveEmptyEntries);
            for(int i = 0;i < arr.Length;i++)
            {
                string first = arr[i].Substring(0, 1).ToUpper();
                string second = arr[i].Substring(1).ToLower();
                arr[i] = first + second;
            }
            s1Txt.Text = String.Join(" ", arr);
        }

        private void getSubString_Click(object sender, EventArgs e)
        {
            getOrigin();
            int start = int.Parse(fromTxt.Text);
            int end = int.Parse(toTxt.Text);
            if (start < 0 || end > s1Txt.Text.Length) return;
            MessageBox.Show("Chuỗi được lấy ra là : " + s1Txt.Text.Substring(start, end));
        }

        private void restoreBt_Click(object sender, EventArgs e)
        {
            s1Txt.Text = restore;
        }
        private void getOrigin()
        {
            if(restore != String.Empty && s1Txt.Text == String.Empty)
            {
                return;
            }
            restore = s1Txt.Text;
        }
    }
}
