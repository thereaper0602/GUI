﻿namespace BTTH3_1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txtTuSo1 = new System.Windows.Forms.TextBox();
            this.txtMauSo1 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtTuSo2 = new System.Windows.Forms.TextBox();
            this.txtMauSo2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtMauSo3 = new System.Windows.Forms.TextBox();
            this.txtTuSo3 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.opeLb = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.addBt = new System.Windows.Forms.Button();
            this.substractBt = new System.Windows.Forms.Button();
            this.multiBt = new System.Windows.Forms.Button();
            this.divideBt = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Blue;
            this.label1.Location = new System.Drawing.Point(1, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(839, 75);
            this.label1.TabIndex = 0;
            this.label1.Text = "CÁC PHÉP TÍNH TRÊN PHÂN SỐ";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.txtMauSo1);
            this.panel1.Controls.Add(this.txtTuSo1);
            this.panel1.Location = new System.Drawing.Point(21, 103);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(171, 209);
            this.panel1.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.txtTuSo2);
            this.panel2.Controls.Add(this.txtMauSo2);
            this.panel2.Location = new System.Drawing.Point(324, 103);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(171, 209);
            this.panel2.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label4);
            this.panel3.Controls.Add(this.txtTuSo3);
            this.panel3.Controls.Add(this.txtMauSo3);
            this.panel3.Location = new System.Drawing.Point(627, 103);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(171, 209);
            this.panel3.TabIndex = 1;
            // 
            // txtTuSo1
            // 
            this.txtTuSo1.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTuSo1.Location = new System.Drawing.Point(29, 35);
            this.txtTuSo1.Name = "txtTuSo1";
            this.txtTuSo1.Size = new System.Drawing.Size(105, 47);
            this.txtTuSo1.TabIndex = 0;
            // 
            // txtMauSo1
            // 
            this.txtMauSo1.BackColor = System.Drawing.SystemColors.Window;
            this.txtMauSo1.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMauSo1.Location = new System.Drawing.Point(29, 126);
            this.txtMauSo1.Name = "txtMauSo1";
            this.txtMauSo1.Size = new System.Drawing.Size(105, 47);
            this.txtMauSo1.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Blue;
            this.label2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label2.Location = new System.Drawing.Point(35, 99);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 12);
            this.label2.TabIndex = 1;
            this.label2.Text = " ";
            // 
            // txtTuSo2
            // 
            this.txtTuSo2.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTuSo2.Location = new System.Drawing.Point(34, 35);
            this.txtTuSo2.Name = "txtTuSo2";
            this.txtTuSo2.Size = new System.Drawing.Size(105, 47);
            this.txtTuSo2.TabIndex = 0;
            // 
            // txtMauSo2
            // 
            this.txtMauSo2.BackColor = System.Drawing.SystemColors.Window;
            this.txtMauSo2.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMauSo2.Location = new System.Drawing.Point(34, 126);
            this.txtMauSo2.Name = "txtMauSo2";
            this.txtMauSo2.Size = new System.Drawing.Size(105, 47);
            this.txtMauSo2.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Blue;
            this.label3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label3.Location = new System.Drawing.Point(40, 99);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 12);
            this.label3.TabIndex = 1;
            this.label3.Text = " ";
            // 
            // txtMauSo3
            // 
            this.txtMauSo3.BackColor = System.Drawing.SystemColors.Window;
            this.txtMauSo3.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMauSo3.Location = new System.Drawing.Point(32, 126);
            this.txtMauSo3.Name = "txtMauSo3";
            this.txtMauSo3.Size = new System.Drawing.Size(105, 47);
            this.txtMauSo3.TabIndex = 0;
            // 
            // txtTuSo3
            // 
            this.txtTuSo3.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTuSo3.Location = new System.Drawing.Point(32, 35);
            this.txtTuSo3.Name = "txtTuSo3";
            this.txtTuSo3.Size = new System.Drawing.Size(105, 47);
            this.txtTuSo3.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.BackColor = System.Drawing.Color.Blue;
            this.label4.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label4.Location = new System.Drawing.Point(38, 99);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(88, 12);
            this.label4.TabIndex = 1;
            this.label4.Text = " ";
            // 
            // opeLb
            // 
            this.opeLb.BackColor = System.Drawing.SystemColors.Control;
            this.opeLb.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.opeLb.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.opeLb.ForeColor = System.Drawing.Color.Blue;
            this.opeLb.Location = new System.Drawing.Point(221, 174);
            this.opeLb.Name = "opeLb";
            this.opeLb.Size = new System.Drawing.Size(73, 61);
            this.opeLb.TabIndex = 1;
            this.opeLb.Text = "+";
            this.opeLb.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label5
            // 
            this.label5.BackColor = System.Drawing.SystemColors.Control;
            this.label5.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Blue;
            this.label5.Location = new System.Drawing.Point(525, 174);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(73, 61);
            this.label5.TabIndex = 1;
            this.label5.Text = "=";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // addBt
            // 
            this.addBt.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addBt.ForeColor = System.Drawing.Color.Blue;
            this.addBt.Location = new System.Drawing.Point(221, 355);
            this.addBt.Name = "addBt";
            this.addBt.Size = new System.Drawing.Size(64, 58);
            this.addBt.TabIndex = 2;
            this.addBt.Text = "+";
            this.addBt.UseVisualStyleBackColor = true;
            this.addBt.Click += new System.EventHandler(this.addBt_Click);
            // 
            // substractBt
            // 
            this.substractBt.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.substractBt.ForeColor = System.Drawing.Color.Blue;
            this.substractBt.Location = new System.Drawing.Point(324, 355);
            this.substractBt.Name = "substractBt";
            this.substractBt.Size = new System.Drawing.Size(64, 58);
            this.substractBt.TabIndex = 2;
            this.substractBt.Text = "-";
            this.substractBt.UseVisualStyleBackColor = true;
            this.substractBt.Click += new System.EventHandler(this.substractBt_Click);
            // 
            // multiBt
            // 
            this.multiBt.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.multiBt.ForeColor = System.Drawing.Color.Blue;
            this.multiBt.Location = new System.Drawing.Point(431, 355);
            this.multiBt.Name = "multiBt";
            this.multiBt.Size = new System.Drawing.Size(64, 58);
            this.multiBt.TabIndex = 2;
            this.multiBt.Text = "x";
            this.multiBt.UseVisualStyleBackColor = true;
            this.multiBt.Click += new System.EventHandler(this.multiBt_Click);
            // 
            // divideBt
            // 
            this.divideBt.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.divideBt.ForeColor = System.Drawing.Color.Blue;
            this.divideBt.Location = new System.Drawing.Point(534, 355);
            this.divideBt.Name = "divideBt";
            this.divideBt.Size = new System.Drawing.Size(64, 58);
            this.divideBt.TabIndex = 2;
            this.divideBt.Text = "/";
            this.divideBt.UseVisualStyleBackColor = true;
            this.divideBt.Click += new System.EventHandler(this.divideBt_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(840, 465);
            this.Controls.Add(this.divideBt);
            this.Controls.Add(this.multiBt);
            this.Controls.Add(this.substractBt);
            this.Controls.Add(this.addBt);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.opeLb);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtMauSo1;
        private System.Windows.Forms.TextBox txtTuSo1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtTuSo2;
        private System.Windows.Forms.TextBox txtMauSo2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtTuSo3;
        private System.Windows.Forms.TextBox txtMauSo3;
        private System.Windows.Forms.Label opeLb;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button addBt;
        private System.Windows.Forms.Button substractBt;
        private System.Windows.Forms.Button multiBt;
        private System.Windows.Forms.Button divideBt;
    }
}

