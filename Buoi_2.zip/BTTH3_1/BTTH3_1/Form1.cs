﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BTTH3_1
{
    public partial class Form1 : Form
    {
        private PhanSo p1;
        private PhanSo p2;
        private int tu1, mau1, tu2, mau2;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            p1 = new PhanSo();
            p2 = new PhanSo();
        }

        private void addBt_Click(object sender, EventArgs e)
        {
            try
            {
                tu1 = int.Parse(txtTuSo1.Text);
                mau1 = int.Parse(txtMauSo1.Text);
                tu2 = int.Parse(txtTuSo2.Text);
                mau2 = int.Parse(txtMauSo2.Text);
                opeLb.Text = addBt.Text;
                p1 = new PhanSo(tu1, mau1);
                p2 = new PhanSo(tu2, mau2);
                PhanSo ketQua = p1.Cong(p2);
                txtTuSo3.Text = ketQua.TuSo.ToString();
                txtMauSo3.Text = ketQua.MauSo.ToString();
            }
            catch (FormatException)
            {
                MessageBox.Show("Vui lòng nhập số");
            }
            catch (OverflowException) {
                MessageBox.Show("Số quá lớn hoặc quá nhỏ");
            }
        }

        private void substractBt_Click(object sender, EventArgs e)
        {
            try
            {
                tu1 = int.Parse(txtTuSo1.Text);
                mau1 = int.Parse(txtMauSo1.Text);
                tu2 = int.Parse(txtTuSo2.Text);
                mau2 = int.Parse(txtMauSo2.Text);
                opeLb.Text = substractBt.Text;
                p1 = new PhanSo(tu1, mau1);
                p2 = new PhanSo(tu2, mau2);
                PhanSo ketQua = p1.Tru(p2);
                txtTuSo3.Text = ketQua.TuSo.ToString();
                txtMauSo3.Text = ketQua.MauSo.ToString();
            }
            catch (FormatException)
            {
                MessageBox.Show("Vui lòng nhập số");
            }
            catch (OverflowException)
            {
                MessageBox.Show("Số quá lớn hoặc quá nhỏ");
            }
        }

        private void multiBt_Click(object sender, EventArgs e)
        {
            try
            {
                tu1 = int.Parse(txtTuSo1.Text);
                mau1 = int.Parse(txtMauSo1.Text);
                tu2 = int.Parse(txtTuSo2.Text);
                mau2 = int.Parse(txtMauSo2.Text);
                opeLb.Text = multiBt.Text;
                p1 = new PhanSo(tu1, mau1);
                p2 = new PhanSo(tu2, mau2);
                PhanSo ketQua = p1.Nhan(p2);
                txtTuSo3.Text = ketQua.TuSo.ToString();
                txtMauSo3.Text = ketQua.MauSo.ToString();
            }
            catch (FormatException)
            {
                MessageBox.Show("Vui lòng nhập số");
            }
            catch (OverflowException)
            {
                MessageBox.Show("Số quá lớn hoặc quá nhỏ");
            }
        }

        private void divideBt_Click(object sender, EventArgs e)
        {
            try
            {
                tu1 = int.Parse(txtTuSo1.Text);
                mau1 = int.Parse(txtMauSo1.Text);
                tu2 = int.Parse(txtTuSo2.Text);
                mau2 = int.Parse(txtMauSo2.Text);
                opeLb.Text = divideBt.Text;
                p1 = new PhanSo(tu1, mau1);
                p2 = new PhanSo(tu2, mau2);
                PhanSo ketQua = p1.Chia(p2);
                txtTuSo3.Text = ketQua.TuSo.ToString();
                txtMauSo3.Text = ketQua.MauSo.ToString();
            }
            catch (FormatException)
            {
                MessageBox.Show("Vui lòng nhập số");
            }
            catch (OverflowException)
            {
                MessageBox.Show("Số quá lớn hoặc quá nhỏ");
            }
        }
    }
}
