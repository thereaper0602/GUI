﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BTTH3_1
{
    class PhanSo
    {
        private int tuSo;
        private int mauSo;
        
        public int TuSo {
            get { return this.tuSo; }
            set { this.tuSo = value; }
        }

        public int MauSo
        {
            get { return this.mauSo; }
            set { this.mauSo = value; }
        }

        public PhanSo()
        {
            this.tuSo = 0;
            this.mauSo = 1;
        }

        public PhanSo(int tuSo,int mauSo)
        {
            this.tuSo = tuSo;
            this.mauSo = (mauSo == 0 ? 1 : mauSo);
        }

        public PhanSo Cong(PhanSo p2) {
            int tu = this.tuSo * p2.MauSo + this.mauSo * p2.TuSo;
            int mau = this.mauSo * p2.MauSo;
            PhanSo ketQua = new PhanSo(tu,mau);
            ketQua.rutGon();
            return ketQua;
        }

        public PhanSo Tru(PhanSo p2)
        {
            int tu = this.tuSo * p2.MauSo - this.mauSo * p2.TuSo;
            int mau = this.mauSo * p2.MauSo;
            PhanSo ketQua = new PhanSo(tu, mau);
            ketQua.rutGon();
            return ketQua;
        }

        public PhanSo Nhan(PhanSo p2)
        {
            int tu = this.tuSo *  p2.TuSo;
            int mau = this.mauSo * p2.MauSo;
            PhanSo ketQua = new PhanSo(tu, mau);
            ketQua.rutGon();
            return ketQua;
        }

        public PhanSo Chia(PhanSo p2)
        {
            int tu = this.tuSo * p2.MauSo;
            int mau = this.mauSo * p2.TuSo;
            PhanSo ketQua = new PhanSo(tu, mau);
            ketQua.rutGon();
            return ketQua;
        }

        public void rutGon()
        {
            int us = MyOwnLibrary.UCLN(this.tuSo, this.mauSo);
            if(us > 0)
            {
                this.tuSo /= us;
                this.mauSo /= us;
            }
        }
    }
}
